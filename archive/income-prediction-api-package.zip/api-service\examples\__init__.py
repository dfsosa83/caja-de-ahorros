# Example usage scripts for Income Prediction API
