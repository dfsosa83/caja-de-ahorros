# Core configuration and utilities
